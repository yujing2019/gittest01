from module1.module2.module3 import utils
utils.say_hello()