def func(a,b,c=111):
    print(f"{a},{b},{c}")

func(1,2,3)
func(1,2)
func(a=123,b=3434,c=1232)
func(a=123,c=1232,b=3434)