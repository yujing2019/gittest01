def sumxx(a,b):
    """
    calculate sum of variables
    :param a:
    :param b:
    :return:
    """
    return a+b

print(sumxx(1,2))
print(sumxx(2,3))
print(sumxx(55,3))