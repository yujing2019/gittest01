readsql=open("bigsql.txt").read()
print(readsql)