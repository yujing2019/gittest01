print("in pya.py",__name__)
print("panda",__name__)
if __name__ == "__main__":
    print("this is the author")
"""
for test in this module
"""
