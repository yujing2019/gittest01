"""
Author lyj
"""

#first lesson
idx=0
while idx <= 100:
    if idx % 5==1 :
        print(idx)
    idx +=1 